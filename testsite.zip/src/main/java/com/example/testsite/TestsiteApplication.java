package com.example.testsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestsiteApplication.class, args);
	}

}
