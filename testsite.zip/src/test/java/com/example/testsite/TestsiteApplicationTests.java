package com.example.testsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
